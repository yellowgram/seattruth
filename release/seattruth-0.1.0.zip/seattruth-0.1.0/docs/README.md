# SeatTruth docs

The detector is on `main` and is read-only. Version **0.1.0** includes the zip, the SHA-256, and the Polar packet. Founder typed go-live on 2026-09-26. CoS publishes the listing after GitHub Release `v0.1.0` includes the zip. DR#1–#3 are pull requests #1–#3. LaunchGate approved the 4th DR on pull request #4. Implement pull request #5 is merged.

| Doc | What it decides |
| --- | --- |
| [MVP_SCOPE.md](MVP_SCOPE.md) | DR#3 rule ids. Detect-case summaries aligned to P26 and P28. Superseded P-rules stay visible. |
| [DESIGN_REVIEW_DR2.md](DESIGN_REVIEW_DR2.md) | The three adversarial passes inside the DR#2 PR, and the deltas they forced. |
| [DESIGN_REVIEW_DR3.md](DESIGN_REVIEW_DR3.md) | The three adversarial passes inside the DR#3 PR, and the deltas they forced. |
| [DESIGN_REVIEW_DR4.md](DESIGN_REVIEW_DR4.md) | 4th DR gate packet. The APPROVE or REQUEST CHANGES ask for LaunchGate. |
| [MINIMUM_SUPPORT_CHECKLIST.md](MINIMUM_SUPPORT_CHECKLIST.md) | Support checklist v3. Section 5 records the 0.1.0 zip. Delta logs from v1 and v2 stay historical. |
| [POLAR_DELIVERABLES.md](POLAR_DELIVERABLES.md) | CoS packet for the one Polar SKU. No Checkout URL. |
| [CHECKSUMS.md](CHECKSUMS.md) | Lowercase SHA-256 of `release/seattruth-0.1.0.zip`. |
| [BUYER_NEEDS_BEYOND_CHECKLIST.md](BUYER_NEEDS_BEYOND_CHECKLIST.md) | Buyer needs v3. Auto-fix and Soft-WTP are refused, including the DR#3 variants. |
| [COMPETITIVE_SKIM.md](COMPETITIVE_SKIM.md) | DR#1 skim, still dated 2026-09-26. DR#2 and DR#3 did not add metrics. |
| [ACCEPTANCE_NOTES.md](ACCEPTANCE_NOTES.md) | Polar scope, Stripe refund recipe, P28 fixtures, and P27 pagination. |
| [CODE_REVIEW_CR1.md](CODE_REVIEW_CR1.md) | CR#1, billing path. P0/P1 fixes and deferred P2 limits. |
| [CODE_REVIEW_CR2.md](CODE_REVIEW_CR2.md) | CR#2, operator safety. P0/P1 fixes and deferred P2 limits. |
| [CODE_REVIEW_CR3.md](CODE_REVIEW_CR3.md) | CR#3, buyer path. P0/P1 fixes and deferred P2 limits. |
| [CODE_REVIEW_CR4.md](CODE_REVIEW_CR4.md) | 4th code-review gate packet. Ask is APPROVE squash-merge or REQUEST CHANGES. |
| [STATUS.md](STATUS.md) | Detector on `main`. 0.1.0 zip, checksum, and Polar packet. |

Front door for an operator: [../BUYER_START_HERE.md](../BUYER_START_HERE.md).

Contact: hello@yellowgram.dev · prefer [www.yellowgram.dev](https://www.yellowgram.dev).
